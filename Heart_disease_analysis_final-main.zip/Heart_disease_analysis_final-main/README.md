# Algorithm-on-Heart-Dataset
Here, I have used the heart dataset and applied various algorithms to predict the output
